/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques3;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques3 {
    public static void main(String[] args) {
        
        int sum = 0;
        Scanner in = new Scanner(System.in);
        System.out.println("Enter number of terms: " );
        int n = in.nextInt();
        System.out.println("Enter value of x");
        int x = in.nextInt();
        for(int i=1;i<=n;i++)
        {
            sum = sum+i;
        }
        sum = sum*x;
        System.out.println("sum is: " + sum);
        
    }
    
}
