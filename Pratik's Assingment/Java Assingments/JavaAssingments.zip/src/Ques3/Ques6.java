/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques3;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;
public class Ques6 {
    public static void main(String[] args) {
        for(int i = 1 ;i<=3;i++)
        {
            for(int j=1;j<=3;j++)
            {
                for(int k = 3;k<=3;k++)
                {
                    
                        System.out.println(i+""+j+""+k);
                   
                }
            }
        }
    }
    
}
