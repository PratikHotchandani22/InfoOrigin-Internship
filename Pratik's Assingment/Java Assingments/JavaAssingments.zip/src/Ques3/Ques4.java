/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques3;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques4 {
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any number");
        int n = in.nextInt();
        int sum = 0;
        int c1 = 0;
        int c2 = 1;
        sum = c1 + c2 + sum;
        System.out.print(" " + c1);
        System.out.print("+" + c2);
        
        //starting loop 
        int n3 = 0;
        for(int i = 2; i<n ;i++)
        {
           
            n3 = c1 + c2;
            System.out.print("+" + n3);
            sum = sum + n3;
            c1 = c2;
            c2 = n3;
            
            
            
        }
        System.out.println(" ");
        System.out.println("Sum is: " + sum);
    }
}
