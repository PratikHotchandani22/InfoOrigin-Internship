/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques3;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any number");
        int n = in.nextInt();
        int sum = 0;
        int c1 = 0;
        int c2 = 1;
        System.out.println(" " + c1);
        System.out.println(" " + c2);
        
        //starting loop 
        int n3 = 0;
        for(int i = 2; i<n ;i++)
        {
            n3 = c1 + c2;
            System.out.println(" " + n3);
            c1 = c2;
            c2 = n3;
            
            
        }
        
    }
    
}
