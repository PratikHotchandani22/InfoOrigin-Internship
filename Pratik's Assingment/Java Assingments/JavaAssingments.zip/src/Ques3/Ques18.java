/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques3;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques18 {
    public static void main(String[] args) {
        
        for(int i=0;i<7;i++)
        {
            for(int j=7;j>i;j--)
            {
                System.out.print((char)(72-j));
            }
            
            System.out.println(" ");
            
        }
    }
}
