/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques3;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;
public class Ques10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any number");
        int n = in.nextInt();
        int count = 0;
        int rev = 0;
        while(n!=0)
        {
        rev=rev*10+(n%10);
        n=n/10;
        ++count;
        }
        for(int i=0;i<count;i++)
        {
            System.out.print(rev%10 + 1);
            rev = rev/10;
        }
        
        
    }
    
}
