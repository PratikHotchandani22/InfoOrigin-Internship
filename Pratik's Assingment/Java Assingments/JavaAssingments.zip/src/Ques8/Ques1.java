/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques8;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

class college
{
    String colgn,Deptn;
    int cap;
    int fees;
    college(String colgn,String Deptn, int cap, int fees)
    {
        this.colgn = colgn;
        this.Deptn = Deptn;
        this.cap = cap;
        this.fees = fees;
        
    }
    
}



public class Ques1 {
    public static void main(String[] args) {
        
        college[] arr;
        arr = new college[2];
        arr[0] = new college("vit","cse",2,3);
        arr[1] = new college("miet","ctech",3,2);
        for(int i=0;i<arr.length;i++)
        {
            System.out.println("Student " + i + ":" + arr[i].colgn + " " + arr[i].Deptn + " " + arr[i].cap + " " + arr[i].fees);
        }
        
    }
    
}
