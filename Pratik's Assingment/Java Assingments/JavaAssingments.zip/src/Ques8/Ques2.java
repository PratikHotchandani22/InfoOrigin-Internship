/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques8;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;


class Cricket
{
    String Pname, Tname;
    Double btnavrg;
    Cricket(String Pname, String Tname,Double btnavrg)
    {
        this.Pname = Pname;
        this.Tname = Tname;
        this.btnavrg = btnavrg;
    }
}





public class Ques2 {
    public static void main(String[] args) {
        Cricket[] player;
        player = new Cricket[2];
        player[0] = new Cricket("Pratik","GP",90.00);
        player[1] = new Cricket("Nikhil","GF",101.00);
        for(int i=0;i<player.length;i++)
        {
            System.out.println("Player:" + i + ": " + player[i].Tname + " " + player[i].Pname + " " + player[i].btnavrg);
        }
        
    }
}
