/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques8;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;


class parent
{
    String name = "my name is pratik";
    
    class child
    {
        void printName()
        {
            System.out.println("In parent class is: " + name);
        }
    }
}

public class Ques4 {
    public static void main(String[] args) {
        parent parobj = new parent();
        parent.child childObj = parobj.new child();
        
        childObj.printName();
        
    }
}
