/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques8;

/**
 *
 * @author HOTIE
 */
import java.util.*;
import java.util.*;
import java.lang.Math;


class time
{
    int hours,mins;
    
    
}


public class Ques3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        time user1 = new time();
        System.out.println("User1 enter hours");
        user1.hours = in.nextInt();
        System.out.println("User1 enter mins");
        user1.mins = in.nextInt();
        time user2 = new time();
        System.out.println("User1 enter hours");
        user2.hours = in.nextInt();
        System.out.println("User2 enter mins");
        user2.mins = in.nextInt();
        int hoursDiff = 0;
        int minsDiff = 0;
        
        if(user1.mins <=59 && user2.mins <=59)
        {
            hoursDiff = Math.abs(user1.hours - user2.hours);
            minsDiff = Math.abs(user1.mins - user2.mins);
            System.out.println("the difference is: " + hoursDiff + "h " + minsDiff + "m");
        }
        else 
        {
            System.out.println("Enter mins in range, that is less than or equal to 59");
        }
        
        
        
    }
}
