/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques1;

/**
 *
 * @author HOTIE
 */

import java.util.*;
import java.io.*;


public class Que2 {
    public static void main(String[] args) {
        
    Scanner in = new Scanner(System.in);
    System.out.println("Please give input");
    char input = in.next().charAt(0);   
    int ascii = (int) input;
    //System.out.println(ascii);
    
    if(ascii >= 48 && ascii <= 57)
    {
        System.out.println("Digit");
    }
    else if(ascii >= 65 && ascii <= 90)
    {
        System.out.println("Capital Alphabet");
    }
    else if(ascii >=97 && ascii <= 122 )
    {
        System.out.println("Small Alphabet");
    }
    else
    {
        System.out.println("Special Character");
    }        
      
    
        
    }
    
}
