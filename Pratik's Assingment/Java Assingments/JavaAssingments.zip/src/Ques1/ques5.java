/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques1;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class ques5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter first number");
        int a = in.nextInt();
        System.out.println("Enter second number");
        int b = in.nextInt();
        int c = 0;
        System.out.println("Choose operation: ");
        System.out.println("1. Addition");
        System.out.println("2. Subtraction");
        System.out.println("3. Division");
        System.out.println("4. Multiplication");
        System.out.println("5. Mod Operation");
        System.out.println("Enter your choice");
        int choice = in.nextInt();
        switch(choice)
                {
                    case 1:
                        c = a + b;
                        System.out.println("After Addition: " + c);
                        break;
                        
                    case 2:
                        c = a - b;
                        System.out.println("After Subtraction: " + c );
                        break;
                    
                            
                    case 3:
                        if(b != 0)
                        {
                            c = a / b;
                            System.out.println("After Division: " + c );
                            break;
                        }
                        else
                        {
                            System.out.println("Can not divide with zero");
                            break;
                        }
                        
                        
                            
                    case 4:
                        c = a * b;
                        System.out.println("After Multiplication: " + c );
                        break;
                        
                            
                    case 5:
                        if(b != 0)
                        {
                            c = a % b;
                            System.out.println("After Division: " + c );
                            break;
                        }
                        else
                        {
                            System.out.println("error");
                            break;
                        }
                        
                            
                    default:
                        System.out.println("You entered wrong choice");
                        break;
                        
                        
                }
        
        
        
    }
    
}
