/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques1;

/**
 *
 * @author HOTIE
 */

import java.io.*;
import java.util.*;

public class ques4 {
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        
    }
    
}
