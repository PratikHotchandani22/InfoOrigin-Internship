/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques1;
import java.util.*;
import java.io.*;
/**
 *
 * @author HOTIE
 */
public class Que1 {
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int a,b,c,d;
        System.out.println("Enter first number");
        a = in.nextInt();
        
        System.out.println("Enter second number");
        b = in.nextInt();
        
        System.out.println("Enter third number");
        c = in.nextInt();
        
        System.out.println("Enter fourth number");
        d = in.nextInt();
        
       
       /* if(a>b && a>c && a>d)
        {
            System.out.println("Greatest is: " + a);
            
        }
        else if(b>a && b>c && b>d)
        {
            System.out.println("Greatest is: " + b);
        }
        else if(c>a && c>b && c>d)
        {
            System.out.println("Greatest is: " + c);
        }
        else if(a<b && a<c && a<d)
        {
            System.out.println("Smallest is: " + a);
        }
        else if(b<c && b<d && b<a)
        {
            System.out.println("Smallest is: " + b);
        }
        else if(c<b && c<a && c<d)
        {
            System.out.println("Smallest is: " + c);
        }
        else
        {
            System.out.println("Smallest is: " + d);
        }

*/
        
    }
    
}
