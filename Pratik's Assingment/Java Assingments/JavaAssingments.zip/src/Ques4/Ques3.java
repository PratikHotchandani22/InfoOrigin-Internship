/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques4;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;


class func
{
    void power(int a, int b)
    {
        double result = Math.pow(a,b);
        System.out.println("Answer is: " + result);
    }
}

public class Ques3 {
    
    
    
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        System.out.println("Enter base");
        int a = in.nextInt();
        System.out.println("enter power");
        int b = in.nextInt();
        func obj1 = new func();
        obj1.power(a,b);
        
        
        
        
    }
}
