/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques4;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

class qu5
{
    void rev()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any number");
        int n = in.nextInt();
        int rev = 0;
        while(n!=0)
        {
        rev=rev*10+(n%10);
        n=n/10; 
        }
        System.out.println("Reverse is: " + rev);
    }
}

public class Ques5 {
    public static void main(String[] args) {
        qu5 obj1 = new qu5();
        obj1.rev();
    }
    
}
