/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques5;

/**
 *
 * @author HOTIE
 */

import java.io.*;
import java.util.*;

public class Ques6 {
    
     public static int addNumbers(int num) {
        if (num != 0)
            return num + addNumbers(num - 1);
        else
            return num;
    }
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("For how many first n numbers running sum is to be calculated? ");
        int number = in.nextInt();
        int sum = addNumbers(number);
        System.out.println("Sum = " + sum);
        
    }
    
}
