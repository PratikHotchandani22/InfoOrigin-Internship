/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques5;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques3 {
    
    
    public static void reverseMethod(int number) {
       if (number < 10) {
	   System.out.println(number);
	   return;
       }
       else {
           System.out.print(number % 10);
           //Method is calling itself: recursion
           reverseMethod(number/10);
       }
    }
    
public static void main(String[] args) {
        
	System.out.println("Input your number: ");
	Scanner in = new Scanner(System.in);
	int num = in.nextInt();
	System.out.print("Reverse of the input number is:");
	reverseMethod(num);
	System.out.println();
    }
    
}
