/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques5;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques5 {
    
    public static int addNumbers(int num) {
        if (num != 0)
            return num + addNumbers(num - 1);
        else
            return num;
    }
    
    public static void main(String[] args) {
        int number = 25;
        int sum = addNumbers(number);
        System.out.println("Sum = " + sum);
        
    }
    
}
