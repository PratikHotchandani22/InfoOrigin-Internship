/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques7;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques5 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any string");
        String s = in.nextLine();
        int chara=0,alpha=0,upr=0,low=0,digits=0,spcl=0,spaces=0,words=0,vowels=0,consonants=0;
        char c[]= s.toCharArray();
        int n = s.length();
        for(int i=0;i<s.length();i++)
        {
            System.out.println(Integer.parseInt(String.valueOf(s.charAt(i))));
            if(Integer.parseInt(String.valueOf(c[i]))>= 0 && Integer.parseInt(String.valueOf(c[i]))<=127)
            {
                chara++;
            }
            if(Integer.parseInt(String.valueOf(c[i]))>= 65 && Integer.parseInt(String.valueOf(c[i]))<=90)
            {
                upr++;
            }
            if(Integer.parseInt(String.valueOf(c[i]))>=97 && Integer.parseInt(String.valueOf(c[i]))<=122)
            {
                low++;
            }
            if(Integer.parseInt(String.valueOf(c[i]))>=48 && Integer.parseInt(String.valueOf(c[i]))<=57)
            {
                digits++;
            }
            if(Integer.parseInt(String.valueOf(c[i]))==32)
            {
                spaces++;
            }
            if(Integer.parseInt(String.valueOf(c[i])) == 65 || Integer.parseInt(String.valueOf(c[i])) == 97 || Integer.parseInt(String.valueOf(c[i])) == 69 || Integer.parseInt(String.valueOf(c[i])) == 101 || Integer.parseInt(String.valueOf(c[i])) == 69 || Integer.parseInt(String.valueOf(c[i])) == 105 || Integer.parseInt(String.valueOf(c[i]))==73 || Integer.parseInt(String.valueOf(c[i]))==111 || Integer.parseInt(String.valueOf(c[i]))==79 || Integer.parseInt(String.valueOf(c[i]))==117 || Integer.parseInt(String.valueOf(c[i]))==85)
            {
                vowels++;
            }
              
        }
            char ch[]= new char[s.length()];     
            for(int i=0;i<s.length();i++)  
            {  
                ch[i]= s.charAt(i);  
                if( ((i>0)&&(ch[i]!=' ')&&(ch[i-1]==' ')) || ((ch[0]!=' ')&&(i==0)) )  
                    words++;
           
        }
        alpha = upr+ low;
        spcl = n-chara-spaces-alpha;
        consonants = alpha-vowels;
        System.out.println("Characters: " + chara + " Alphabtes: " + alpha + " UpperCase: " + upr + " LowerCase: " + low + " Digits: " + digits + " SpecialSymbols: " + spcl + " Spaces: " + spaces +" Words: " + words +" Vowels: " + vowels + " Consonants: " + consonants);
    }
    
}
