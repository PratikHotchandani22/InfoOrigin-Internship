/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques7;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        String s;
        System.out.println("Enter a Sting");
        s = in.next();
        char c;
        System.out.println("Enter the character to find");
        c=in.next().charAt(0);
        int n = s.length();
        char sarr[] = new char[n];
        for(int i=0;i<n;i++)
        {
            sarr[i] = s.charAt(i);
        }
        for(int i=0;i<n;i++)
        {
            if(sarr[i] == c)
            {
                System.out.println("position of the character " + c + " is: " + i+1);
            }
        }
       
        
    }
    
}
