/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques7;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques8 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any string");
        String s = in.next();
        String reverse = ""; // Objects of String class
     
     
    
     
      int length = s.length();
     
      for (int i = length - 1; i >= 0; i--)
         reverse = reverse + s.charAt(i);
         
      if (s.equals(reverse))
         System.out.println("The string is a palindrome.");
      else
         System.out.println("The string isn't a palindrome.");
    }
    
}
