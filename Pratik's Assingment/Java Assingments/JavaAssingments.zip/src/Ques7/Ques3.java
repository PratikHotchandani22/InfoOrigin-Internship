/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques7;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any  string");
        String s1 = in.nextLine();
        //char c[] = s.toCharArray();
        //String Scopied;
        String s2= "" + s1;
        System.out.println("String s2 after being copied from string s1 is: " + s2 );
        
        
    }
    
}
