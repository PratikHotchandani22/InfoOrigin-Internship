/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques7;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques4 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter String1");
        String s1 = in.next();
        System.out.println("Enter String2");
        String s2 = in.next();
        String s3 = s1 +" " +  s2;
        System.out.println("Final string after concatenation is: " + s3);
    }
   
}
