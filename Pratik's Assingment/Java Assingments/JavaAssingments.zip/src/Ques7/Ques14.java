/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques7;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;


public class Ques14 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any string");
        String s = in.next();
        char c[] = s.toCharArray();
        boolean num = true;
        for(int i=0;i<s.length();i++)
        {
            System.out.println(c[i]);
            if(c[i]==(char)46)
            {
                num = true;
                continue;
            }
            
            else if(c[i]>=(char)48 && c[i]<=(char)57)
            {
                num = true;
                continue;
            }
            else
            {
                num = false;
                break;
            }
        }
        System.out.println(num);
    }
}
