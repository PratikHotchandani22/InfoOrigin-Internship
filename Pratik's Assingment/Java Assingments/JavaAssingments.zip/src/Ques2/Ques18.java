/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */

import java.io.*;
import java.util.*;

public class Ques18 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter your gender");
        char g = in.next().charAt(0);
        System.out.println("Enter your balance");
        double bal = in.nextDouble();
        if(g == 'f')
        {
            if(bal >=5000)
            {
                bal = 1.05*bal;
            }
            else
            {
                bal = 1.02*bal;
            }
        }
        else if(g == 'm')
        {
            bal = 1.02*bal;
        }
        System.out.println("final balance is: " + bal);
    }
    
}
