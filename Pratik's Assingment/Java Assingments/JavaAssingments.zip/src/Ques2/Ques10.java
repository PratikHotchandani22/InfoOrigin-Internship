/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */

import java.io.*;
import java.util.*;

public class Ques10 {
    
    public static void main(String[] args) {
    
        Scanner in = new Scanner(System.in);
        
        System.out.println("Enter any number");
        int n = in.nextInt();
        int rev = 0;
        int m=0;
        
        
        System.out.println("Answer is: ");
        while(n!=0)
        {
        rev=rev*10+(n%10);
        n=n/10; 
        }
        while(rev!=0)
        {
            m = rev%10;
            switch(m)
            {
                case 0:
                    System.out.println("zero \t");
                    break;
                    
                case 1:
                    System.out.println("one \t");
                    break;
                    
                case 2:
                    System.out.println("two \t");
                    break;
                    
                 case 3:
                    System.out.println("three \t");
                    break;
                    
                case 4:
                    System.out.println("four \t");
                    break;
                    
                case 5:
                    System.out.println("five \t");
                    break;
                    
                case 6:
                    System.out.println("six \t");
                    break;
                    
                case 7:
                    System.out.println("seven \t");
                    break;
                    
                case 8:
                    System.out.println("eight \t");
                    break;
                    
                case 9:
                    System.out.println("nine \t");
                    break;
                    
                
              }
            rev = rev/10;
        }
        
    }
}

