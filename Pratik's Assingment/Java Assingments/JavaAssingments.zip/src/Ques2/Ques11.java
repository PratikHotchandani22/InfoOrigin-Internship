/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;


public class Ques11 {
    public static void main(String[] args) {
    Scanner in = new Scanner(System.in);
    System.out.println("Enter marks scored");
    int marks = in.nextInt();
    if(marks>= 8 && marks<=10)
    {
        System.out.println("Excellent");
    }
    else if(marks == 7)
    {
        System.out.println("Very Good");
    }
    else if(marks == 6)
    {
        System.out.println("Good");
    }
    else if(marks == 5)
    {
        System.out.println("Work Hard");
    }
    else if(marks == 4)
    {
        System.out.println("Poor");
    }
    else if(marks>= 0 && marks <=3)
    {
        System.out.println("Very Poor");
    }
    else
    {
        System.out.println("marks not entered correctly");
    }
    }
    
}
