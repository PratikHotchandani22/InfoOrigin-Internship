/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques17 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int sum = 0;
        int rand = 1;
        int n = in.nextInt();
        for(int i =0 ;i<n;i++)
        {
            rand = rand + i;
            sum = sum + rand;
        }
        System.out.println("Sum is: "+ sum);
    }
    
}
