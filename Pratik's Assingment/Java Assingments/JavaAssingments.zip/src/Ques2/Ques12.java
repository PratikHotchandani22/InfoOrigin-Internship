/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;
public class Ques12 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the value of n");
        int n = in.nextInt();
        int num[] = new int[n];
        System.out.println("Enter " + n + " numbers");
        for(int i=0;i<n;i++)
        {
            num[i] = in.nextInt();
            
        }
        //sorting array
        Arrays.sort(num);
        System.out.println("largest number is: " + num[n-1]);
        System.out.println("Second largest number is: " + num[n-2]);
        
        
    }
    
}
