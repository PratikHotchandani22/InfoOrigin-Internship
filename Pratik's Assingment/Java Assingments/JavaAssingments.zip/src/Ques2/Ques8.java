/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques8 {
    public static void main(String[] args) {
        int count=0;
        int sum = 0;
        for(int i=101;i<=200;i=i+2)
        {
            if(i%5==0)
            {
                continue;
                
            }
            else
            {
                count++;
                sum  = sum + i;
                System.out.println(i);
            }
        }
        System.out.println("Count is: " + count);
        System.out.println("Sum is: " + sum );
        
    }
    
}
