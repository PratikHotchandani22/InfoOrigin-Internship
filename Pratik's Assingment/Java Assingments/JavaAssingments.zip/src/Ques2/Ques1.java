/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques1 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter number of integers you want to compare");
        int n = in.nextInt();
        int[] arr= new int[n];
        for(int i=0;i<n;i++)
        {
            arr[i] = in.nextInt();
            
        }
        Arrays.sort(arr);
        System.out.println("Smallest is: " + arr[0]);
        System.out.println("Largest is: " + arr[n-1]);
        
        
    }
    
}
