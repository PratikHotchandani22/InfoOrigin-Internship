/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */

import java.util.*;
import java.io.*;

public class ques3 {
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter First number");
        int a = in.nextInt();
        System.out.println("Enter second number");
        int b = in.nextInt();
        int c = (int) Math.pow(a,b);
        System.out.println("Answer is: " + c);
        
        
    }
    
}
