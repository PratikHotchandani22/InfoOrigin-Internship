/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques2;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques13 {
    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any number");
        int n = in.nextInt();
        do
        {

            if(n>0)
            {
                System.out.println("Positive number");
                continue;
            }
            else if(n<0)
            {

                System.out.println("Negative number");
                continue;
            }
            else if(n==-999)
            {
                break;
            }
            else
            {
                System.out.println("Zero");
                continue;
            }
        }
        while(n!=-999);
    }
    
}
