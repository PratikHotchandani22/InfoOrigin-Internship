/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Linrqeu;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Linrequ {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter any string in x, i.e a linear equation");
        String s = in.nextLine();
        double finalval ;
        double xconst =0.0;
        double xconstl = 0.0;
        double xconstr = 0.0;
        double valconst=0.0;
        double valconstl = 0.0;
        double valconstr = 0.0;
        int equpos = 0;
        char c[] = s.toCharArray();
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i) == '=')
            {
                equpos = i;
            }
        }
        System.out.println("Equpos is: " + equpos);
        for(int i=0;i<equpos;i++)
        {
            
            //calculating x before = 
            if(s.charAt(i)== 'x')
            {
                if(i==0)
                {
                    xconstl++;
                }
                else if(i==1)
                {
                    xconstl = xconstl + Integer.parseInt(String.valueOf(c[i-1]));
                }
                else if(i>1 && i<equpos)
                {
                    if(s.charAt(i-1) == '+')
                    {
                        xconstl++;
                    }
                    else if(s.charAt(i-1) == '-')
                    {
                        xconstl--;
                    }
                    else if(s.charAt(i-2) == '+')
                    {
                        xconstl = xconstl + Integer.parseInt(String.valueOf(c[i-1]));
                    }
                    else if(s.charAt(i-2) == '-')
                    {
                        xconstl = xconstl - Integer.parseInt(String.valueOf(c[i-1]));
                    }
                }
           
            }
            //calculating const value before =
            else if(s.charAt(i)>=(char)48 && s.charAt(i)<=(char)57 && s.charAt(i+1)!='x')
                    {
                        if(i==0)
                        {
                            valconstl = valconstl + Integer.parseInt(String.valueOf(c[i]));
                        }
                        else if(s.charAt(i-1) == '+')
                        {
                            valconstl = valconstl + Integer.parseInt(String.valueOf(c[i]));
                        }
                        else if(s.charAt(i-1) == '-')
                        {
                            valconstl = valconstl - Integer.parseInt(String.valueOf(c[i]));
                        }
                        
                        
                    }
            System.out.println("xconstl: " + xconstl);
            System.out.println("Valconstl: " + valconstl);
            
            //calculating const value before =
            
            
        }
        
        for(int i=equpos+1;i<s.length();i++)
        {
            //calculating xconst after = 
            if(s.charAt(i)== 'x')
            {
                if(i==equpos+1)
                {
                    xconstr++;
                }
                else if(i==equpos+2)
                {
                    xconstr = xconstr + Integer.parseInt(String.valueOf(c[i-1]));
                }
                else if(i>equpos+2 && i<s.length())
                {
                    if(s.charAt(i-1) == '+')
                    {
                        xconstr++;
                    }
                    else if(s.charAt(i-1) == '-')
                    {
                        xconstr--;
                    }
                    else if(s.charAt(i-2) == '+')
                    {
                        xconstr = xconstr + Integer.parseInt(String.valueOf(c[i-1]));
                    }
                    else if(s.charAt(i-2) == '-')
                    {
                        xconstr = xconstr - Integer.parseInt(String.valueOf(c[i-1]));
                    }
                }
                
            }
            //calculating const value after =
            else if(s.charAt(i)>=(char)48 && s.charAt(i)<=(char)57 )
                    {
                        if(i==equpos+1)
                        {
                            valconstr = valconstr + Integer.parseInt(String.valueOf(c[i]));
                        }
                        else if(s.charAt(i-1) == '+')
                        {
                            valconstr = valconstr + Integer.parseInt(String.valueOf(c[i]));
                        }
                        else if(s.charAt(i-1) == '-')
                        {
                            valconstr = valconstr - Integer.parseInt(String.valueOf(c[i]));
                        }
                        
                        
                        
                    }
            valconstr = valconstr-xconstr;
            System.out.println("xconstr = " + xconstr);
            System.out.println("valconstr: " + valconstr);
            
        }
        if(xconstl>xconstr)
        {
            xconst = xconstl-xconstr;
        }
        else if(xconstr>xconstl)
        {
            xconst = xconstr-xconstl;
        }
        else
        {
            xconst = 0;
        }
        System.out.println("xconst is : " + xconst);
        
         if(valconstl>valconstr)
        {
            System.out.println("val lef is larger");
            valconst = valconstl-valconstr;
        }
        else if(valconstr>valconstl)
        {
            valconst = valconstr-valconstl;
            System.out.println("val right is larger");
        }
        else
        {
            System.out.println("none is larger");
            valconst = 0;
        }
         System.out.println("constant value is: " + valconst);
        
        finalval = valconst/xconst;
        System.out.println("final value is: " + finalval);
    }
    
}
