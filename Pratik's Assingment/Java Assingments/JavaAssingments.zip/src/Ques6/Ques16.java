/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques6;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques16 {
    public static void main(String[] args) {
        //creating a matrix  
        Scanner in = new Scanner(System.in);
        System.out.println("Enter number of rows");
        int rows = in.nextInt();
        System.out.println("Enter number of cols");
        int cols= in.nextInt();
        System.out.println("Enter elements into matrix");
        int original[][] = new int[rows][cols];
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                original[i][j] = in.nextInt();
            }
        }
        
        
        
            

        //creating another matrix to store transpose of a matrix  
        int transpose[][]=new int[rows][cols];  //3 rows and 3 columns  

        //Code to transpose a matrix  
        for(int i=0;i<3;i++){    
        for(int j=0;j<3;j++){    
        transpose[i][j]=original[j][i];  
        }    
        }    

        System.out.println("Printing Matrix without transpose:");  
        for(int i=0;i<3;i++){    
        for(int j=0;j<3;j++){    
        System.out.print(original[i][j]+" ");    
        }    
        System.out.println();//new line    
        }    
        System.out.println("Printing Matrix After Transpose:");  
        for(int i=0;i<3;i++){    
        for(int j=0;j<3;j++){    
        System.out.print(transpose[i][j]+" ");    
        }    
        System.out.println();//new line 
        }
        
    }
    
}
