/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques6;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques3 {
    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        System.out.println("enter number of elements");
        int n = in.nextInt();
        System.out.println("Enter " + n + " elements");
        int arr[] = new int[n];
        for(int i=0;i<n;i++)
        {
            arr[i]=in.nextInt();
        }
        System.out.println("Enter the number you want to delete");
        int x = in.nextInt();
        int index = 0;
        for(int i=0;i<n;i++)
        {
            if (arr[i] != x) 
            {
                arr[index++] = arr[i]; 
            }
         // Create a copy of arr[]  
            System.out.println(Arrays.copyOf(arr, index)); 
        }
        
        
    }
    
}
