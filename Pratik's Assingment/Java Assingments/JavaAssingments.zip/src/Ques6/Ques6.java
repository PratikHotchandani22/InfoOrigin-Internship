/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques6;

/**
 *
 * @author HOTIE
 */

import java.io.*;
import java.util.*;

public class Ques6 {
    
     public static void insertionSort(int array[]) {  
        int n = array.length;  
        for (int j = 1; j < n; j++) {  
            int key = array[j];  
            int i = j-1;  
            while ( (i > -1) && ( array [i] > key ) ) {  
                array [i+1] = array [i];  
                i--;  
            }  
            array[i+1] = key;  
        }  
    }  
    
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter number of terms");
        int n = in.nextInt();
        int arr1[] = new int[n];
        System.out.println("Enter elements");
        for(int i=0;i<n;i++)
        {
            arr1[i] = in.nextInt();
        }
        System.out.println("Before Insertion Sort");    
        for(int i:arr1){    
            System.out.print(i+" ");    
        }    
        System.out.println();    
            
        insertionSort(arr1);//sorting array using insertion sort    
           
        System.out.println("After Insertion Sort");    
        for(int i:arr1){    
            System.out.print(i+" ");    
        }    
    }
}
