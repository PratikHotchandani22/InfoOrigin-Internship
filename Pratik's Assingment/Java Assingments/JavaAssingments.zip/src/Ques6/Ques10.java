/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques6;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques10 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter number of rows");
        int r = in.nextInt();
        System.out.println("Enter number of cols");
        int c = in.nextInt();
        int mat[][] = new int[r][c];
        System.out.println("enter elements: ");
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                mat[i][j] = in.nextInt();
            }
        }
        System.out.println("matrix is: ");
        for(int i=0;i<r;i++)
        {
            for(int j=0;j<c;j++)
            {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println("");
        }
        
    }
}
