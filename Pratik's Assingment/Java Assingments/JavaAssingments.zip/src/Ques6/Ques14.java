/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ques6;

/**
 *
 * @author HOTIE
 */
import java.io.*;
import java.util.*;

public class Ques14 {
    public static void main(String[] args) {
        
       int  sumRow;
          
       
        Scanner in = new Scanner(System.in);
        System.out.println("Enter number of rows");
        int rows = in.nextInt();
        System.out.println("Enter number of cols");
        int cols= in.nextInt();
        System.out.println("Enter elements into matrix");
        int a[][] = new int[rows][cols];
        for(int i=0;i<rows;i++)
        {
            for(int j=0;j<cols;j++)
            {
                a[i][j] = in.nextInt();
            }
        }
        
        
        for(int i = 0; i < rows; i++){  
            sumRow = 0;  
            for(int j = 0; j < cols; j++){  
              sumRow = sumRow + a[i][j];  
            }  
            System.out.println("Sum of " + (i+1) +" row: " + sumRow);  
        }  
          
      
    

        
        
    }
    
}
